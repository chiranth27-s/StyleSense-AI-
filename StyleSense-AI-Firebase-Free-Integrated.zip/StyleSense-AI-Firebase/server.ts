import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config({ path: '.env.local' });
dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '100kb' }));

// Simple in-memory throttle for free-tier AI endpoints; a demo safeguard only.
const aiRateWindows = new Map<string, { count: number; resetAt: number }>();
function limitAiRequests(req: express.Request, res: express.Response, next: express.NextFunction) {
  const key = req.ip || 'unknown';
  const now = Date.now();
  const state = aiRateWindows.get(key);
  if (!state || now > state.resetAt) { aiRateWindows.set(key, { count: 1, resetAt: now + 60_000 }); next(); return; }
  if (state.count >= 12) { res.status(429).json({ success: false, message: 'Free AI request limit reached. Wait one minute and try again.' }); return; }
  state.count += 1;
  next();
}


// In-memory data structures initialized with rich data
export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  oldPrice?: number;
  rating: number;
  category: string;
  gender: 'Women' | 'Men' | 'Unisex';
  slot: 'Topwear' | 'Bottomwear' | 'Footwear' | 'Accessories';
  color: string;
  palette: string;
  styles: string[];
  occasions: string[];
  image: string;
  featured: boolean;
  tag?: string | null;
  stock: number;
}

export interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image?: string;
  slot?: string;
}

export interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  deliveryAddress: string;
  items: OrderItem[];
  subtotal: number;
  shipping: number;
  total: number;
  status: 'Processing' | 'Dispatched' | 'Delivered' | 'Cancelled';
  paymentMode: string;
  createdAt: string;
}

export interface ServiceProvider {
  id: string;
  name: string;
  category: 'Tailoring' | 'Shoe repair' | 'Bag repair' | 'Watch repair';
  city: string;
  area: string;
  pin: string;
  rating: number;
  priceRange: string;
  icon: string;
  desc: string;
  pickup: boolean;
  contactEmail: string;
  contactPhone: string;
  completedJobsCount: number;
  totalEarnings: number;
}

export interface ServiceBooking {
  id: string;
  providerId: string;
  providerName: string;
  category: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  serviceNotes: string;
  preferredDate: string;
  serviceType: 'Doorstep Pickup & Return' | 'Direct Studio Drop-off';
  status: 'Pickup Scheduled' | 'Received in Workshop' | 'In-Progress / Crafting' | 'Ready for Delivery' | 'Completed';
  cost: number;
  createdAt: string;
  providerNotes?: string;
}

let products: Product[] = [
  // Existing Core Staples
  {
    id: 'p1',
    name: 'Everyday Relaxed Linen Shirt',
    brand: 'Studio North',
    price: 1899,
    oldPrice: 2499,
    rating: 4.9,
    category: 'Clothing',
    gender: 'Women',
    slot: 'Topwear',
    color: 'Ivory',
    palette: 'Neutrals',
    styles: ['Minimal', 'Casual', 'Classic'],
    occasions: ['Everyday', 'Work', 'College'],
    image: 'https://images.unsplash.com/photo-1598554747436-c9293d6a588f?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Bestseller',
    stock: 24
  },
  {
    id: 'p2',
    name: 'Structure Leather Shoulder Bag',
    brand: 'Atelier Edit',
    price: 2199,
    oldPrice: 2899,
    rating: 4.8,
    category: 'Bags',
    gender: 'Women',
    slot: 'Accessories',
    color: 'Black',
    palette: 'Monochrome',
    styles: ['Minimal', 'Classic', 'Romantic'],
    occasions: ['Work', 'Date night', 'Wedding'],
    image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Editorial Pick',
    stock: 12
  },
  {
    id: 'p3',
    name: 'Suede Low-Top Court Trainers',
    brand: 'Sunday Club',
    price: 2499,
    oldPrice: 3200,
    rating: 4.7,
    category: 'Shoes',
    gender: 'Unisex',
    slot: 'Footwear',
    color: 'Sand',
    palette: 'Earth tones',
    styles: ['Minimal', 'Casual', 'Streetwear'],
    occasions: ['College', 'Everyday'],
    image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Wardrobe Staple',
    stock: 18
  },
  {
    id: 'p4',
    name: 'Bauhaus Minimalist Watch 38mm',
    brand: 'Hour & Form',
    price: 1799,
    oldPrice: 2499,
    rating: 4.9,
    category: 'Watches',
    gender: 'Unisex',
    slot: 'Accessories',
    color: 'White',
    palette: 'Neutrals',
    styles: ['Minimal', 'Classic'],
    occasions: ['Work', 'Everyday', 'Wedding'],
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Timeless',
    stock: 15
  },
  {
    id: 'p5',
    name: 'Pleated High-Waist Linen Trouser',
    brand: 'Studio North',
    price: 1950,
    oldPrice: 2500,
    rating: 4.7,
    category: 'Clothing',
    gender: 'Women',
    slot: 'Bottomwear',
    color: 'Beige',
    palette: 'Neutrals',
    styles: ['Minimal', 'Classic', 'Romantic'],
    occasions: ['Work', 'Date night', 'College'],
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: 'New',
    stock: 16
  },
  {
    id: 'p6',
    name: 'Organic Heavyweight Crew Tee',
    brand: 'Common Ground',
    price: 899,
    oldPrice: 1199,
    rating: 4.8,
    category: 'Clothing',
    gender: 'Unisex',
    slot: 'Topwear',
    color: 'White',
    palette: 'Neutrals',
    styles: ['Casual', 'Minimal', 'Streetwear'],
    occasions: ['College', 'Everyday'],
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Under ₹1,000',
    stock: 45
  },
  {
    id: 'p7',
    name: 'Vintage Straight Raw Denim',
    brand: 'Common Ground',
    price: 1899,
    oldPrice: 2400,
    rating: 4.6,
    category: 'Clothing',
    gender: 'Unisex',
    slot: 'Bottomwear',
    color: 'Indigo',
    palette: 'Earth tones',
    styles: ['Casual', 'Streetwear', 'Minimal'],
    occasions: ['College', 'Everyday', 'Date night'],
    image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 20
  },
  {
    id: 'p8',
    name: 'Cloud-Knit Cardigan in Oat',
    brand: 'Maison Studio',
    price: 2199,
    oldPrice: 2899,
    rating: 4.9,
    category: 'Clothing',
    gender: 'Women',
    slot: 'Topwear',
    color: 'Oat',
    palette: 'Soft pastels',
    styles: ['Romantic', 'Minimal', 'Classic'],
    occasions: ['Work', 'Date night', 'Everyday'],
    image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Editor Fav',
    stock: 14
  },
  {
    id: 'p9',
    name: 'Relaxed Oxford Button-Down',
    brand: 'Studio North',
    price: 1699,
    oldPrice: 2199,
    rating: 4.7,
    category: 'Clothing',
    gender: 'Men',
    slot: 'Topwear',
    color: 'Sky Blue',
    palette: 'Soft pastels',
    styles: ['Classic', 'Casual', 'Minimal'],
    occasions: ['Work', 'Wedding', 'College'],
    image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 22
  },
  {
    id: 'p10',
    name: 'Architect Leather Ankle Boot',
    brand: 'Forma Footwear',
    price: 3299,
    oldPrice: 4200,
    rating: 4.8,
    category: 'Shoes',
    gender: 'Women',
    slot: 'Footwear',
    color: 'Black',
    palette: 'Monochrome',
    styles: ['Minimal', 'Streetwear', 'Classic'],
    occasions: ['Date night', 'Work'],
    image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 9
  },
  {
    id: 'p11',
    name: 'Italian Acetate Sun Frames',
    brand: 'Atelier Edit',
    price: 1199,
    oldPrice: 1799,
    rating: 4.7,
    category: 'Accessories',
    gender: 'Unisex',
    slot: 'Accessories',
    color: 'Tortoise',
    palette: 'Earth tones',
    styles: ['Classic', 'Minimal', 'Streetwear'],
    occasions: ['Everyday', 'College', 'Date night'],
    image: 'https://images.unsplash.com/photo-1572635196237-14b3f8a1ff0?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: 'Accessory',
    stock: 30
  },
  {
    id: 'p12',
    name: 'Tailored Wool-Blend Chino',
    brand: 'Common Ground',
    price: 1799,
    oldPrice: 2299,
    rating: 4.6,
    category: 'Clothing',
    gender: 'Men',
    slot: 'Bottomwear',
    color: 'Charcoal',
    palette: 'Monochrome',
    styles: ['Classic', 'Minimal'],
    occasions: ['Work', 'Wedding', 'Date night'],
    image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 19
  },

  // Additional Budget & Mid-Tier Topwear
  {
    id: 'p13',
    name: 'Ribbed Cotton Minimalist Tank',
    brand: 'Studio North',
    price: 499,
    oldPrice: 799,
    rating: 4.8,
    category: 'Clothing',
    gender: 'Women',
    slot: 'Topwear',
    color: 'Beige',
    palette: 'Neutrals',
    styles: ['Minimal', 'Casual', 'Romantic'],
    occasions: ['Everyday', 'College', 'Date night'],
    image: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Under ₹500',
    stock: 50
  },
  {
    id: 'p14',
    name: 'Classic Boxy Oversized Tee',
    brand: 'Common Ground',
    price: 649,
    oldPrice: 899,
    rating: 4.7,
    category: 'Clothing',
    gender: 'Unisex',
    slot: 'Topwear',
    color: 'Charcoal',
    palette: 'Monochrome',
    styles: ['Casual', 'Streetwear', 'Minimal'],
    occasions: ['Everyday', 'College'],
    image: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: 'Essential',
    stock: 40
  },
  {
    id: 'p15',
    name: 'Waffle-Knit Long Sleeve Henley',
    brand: 'Sunday Club',
    price: 899,
    oldPrice: 1299,
    rating: 4.6,
    category: 'Clothing',
    gender: 'Men',
    slot: 'Topwear',
    color: 'Olive',
    palette: 'Earth tones',
    styles: ['Casual', 'Classic'],
    occasions: ['Everyday', 'College'],
    image: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 25
  },
  {
    id: 'p16',
    name: 'Resort Camp Collar Floral Shirt',
    brand: 'Maison Studio',
    price: 1399,
    oldPrice: 1899,
    rating: 4.8,
    category: 'Clothing',
    gender: 'Men',
    slot: 'Topwear',
    color: 'Sage',
    palette: 'Soft pastels',
    styles: ['Romantic', 'Casual'],
    occasions: ['Date night', 'Everyday', 'College'],
    image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: 'Summer Drop',
    stock: 18
  },
  {
    id: 'p17',
    name: 'Silk-Touch Draped Blouse',
    brand: 'Atelier Edit',
    price: 1599,
    oldPrice: 2199,
    rating: 4.9,
    category: 'Clothing',
    gender: 'Women',
    slot: 'Topwear',
    color: 'Cream',
    palette: 'Neutrals',
    styles: ['Classic', 'Romantic'],
    occasions: ['Work', 'Wedding', 'Date night'],
    image: 'https://images.unsplash.com/photo-1551803091-e20673f15770?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: 'Occasion Pick',
    stock: 16
  },
  {
    id: 'p18',
    name: 'Double-Breasted Wool Atelier Blazer',
    brand: 'Studio North',
    price: 3499,
    oldPrice: 4599,
    rating: 4.9,
    category: 'Clothing',
    gender: 'Women',
    slot: 'Topwear',
    color: 'Camel',
    palette: 'Neutrals',
    styles: ['Classic', 'Minimal'],
    occasions: ['Work', 'Wedding', 'Date night'],
    image: 'https://images.unsplash.com/photo-1584273143981-41c073dfe8f8?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Luxury Tailoring',
    stock: 10
  },

  // Additional Budget & Mid-Tier Bottomwear
  {
    id: 'p19',
    name: 'Everyday Linen-Blend Drawstring Shorts',
    brand: 'Sunday Club',
    price: 699,
    oldPrice: 999,
    rating: 4.7,
    category: 'Clothing',
    gender: 'Unisex',
    slot: 'Bottomwear',
    color: 'Sand',
    palette: 'Earth tones',
    styles: ['Casual', 'Minimal'],
    occasions: ['Everyday', 'College'],
    image: 'https://images.unsplash.com/photo-1591195853828-11db59a44f6b?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Under ₹700',
    stock: 35
  },
  {
    id: 'p20',
    name: 'High-Waist Pleated A-Line Midi Skirt',
    brand: 'Maison Studio',
    price: 899,
    oldPrice: 1299,
    rating: 4.8,
    category: 'Clothing',
    gender: 'Women',
    slot: 'Bottomwear',
    color: 'Terracotta',
    palette: 'Earth tones',
    styles: ['Romantic', 'Classic'],
    occasions: ['College', 'Everyday', 'Date night'],
    image: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 22
  },
  {
    id: 'p21',
    name: 'Utility Straight-Leg Cargo Pant',
    brand: 'Common Ground',
    price: 1299,
    oldPrice: 1799,
    rating: 4.7,
    category: 'Clothing',
    gender: 'Unisex',
    slot: 'Bottomwear',
    color: 'Khaki',
    palette: 'Earth tones',
    styles: ['Streetwear', 'Casual'],
    occasions: ['College', 'Everyday'],
    image: 'https://images.unsplash.com/photo-1517445312882-bc9910d016b7?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: 'Street Staple',
    stock: 28
  },
  {
    id: 'p22',
    name: 'Flowy Wide-Leg Tencel Culottes',
    brand: 'Studio North',
    price: 1499,
    oldPrice: 1999,
    rating: 4.8,
    category: 'Clothing',
    gender: 'Women',
    slot: 'Bottomwear',
    color: 'Olive',
    palette: 'Earth tones',
    styles: ['Minimal', 'Romantic'],
    occasions: ['Everyday', 'Work', 'College'],
    image: 'https://images.unsplash.com/photo-1509551388413-e18d0ac5d495?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 18
  },
  {
    id: 'p23',
    name: 'Raw Indigo Loose Skate Jeans',
    brand: 'Common Ground',
    price: 1799,
    oldPrice: 2399,
    rating: 4.6,
    category: 'Clothing',
    gender: 'Unisex',
    slot: 'Bottomwear',
    color: 'Deep Blue',
    palette: 'Monochrome',
    styles: ['Streetwear', 'Casual'],
    occasions: ['College', 'Date night', 'Everyday'],
    image: 'https://images.unsplash.com/photo-1555689502-c4b22d76c56f?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 24
  },
  {
    id: 'p24',
    name: 'Pleated Dress Trousers in Midnight Navy',
    brand: 'Atelier Edit',
    price: 2499,
    oldPrice: 3199,
    rating: 4.9,
    category: 'Clothing',
    gender: 'Men',
    slot: 'Bottomwear',
    color: 'Navy',
    palette: 'Monochrome',
    styles: ['Classic', 'Minimal'],
    occasions: ['Wedding', 'Work'],
    image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Formal Edit',
    stock: 14
  },

  // Additional Budget & Diverse Footwear
  {
    id: 'p25',
    name: 'Minimalist Low Canvas Slip-Ons',
    brand: 'Sunday Club',
    price: 699,
    oldPrice: 999,
    rating: 4.7,
    category: 'Shoes',
    gender: 'Unisex',
    slot: 'Footwear',
    color: 'Off-White',
    palette: 'Neutrals',
    styles: ['Minimal', 'Casual'],
    occasions: ['Everyday', 'College'],
    image: 'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Under ₹700',
    stock: 32
  },
  {
    id: 'p26',
    name: 'Woven Leather-Look Cross Slides',
    brand: 'Maison Studio',
    price: 799,
    oldPrice: 1199,
    rating: 4.8,
    category: 'Shoes',
    gender: 'Women',
    slot: 'Footwear',
    color: 'Tan',
    palette: 'Earth tones',
    styles: ['Romantic', 'Minimal'],
    occasions: ['Everyday', 'College'],
    image: 'https://images.unsplash.com/photo-1603808033192-082d6919d3e1?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 20
  },
  {
    id: 'p27',
    name: 'Vintage Retro Gumsole Skate Shoes',
    brand: 'Common Ground',
    price: 1299,
    oldPrice: 1799,
    rating: 4.7,
    category: 'Shoes',
    gender: 'Unisex',
    slot: 'Footwear',
    color: 'Black',
    palette: 'Monochrome',
    styles: ['Streetwear', 'Casual'],
    occasions: ['College', 'Everyday'],
    image: 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 25
  },
  {
    id: 'p28',
    name: 'Pointed Slingback Kitten Heels',
    brand: 'Atelier Edit',
    price: 1999,
    oldPrice: 2699,
    rating: 4.9,
    category: 'Shoes',
    gender: 'Women',
    slot: 'Footwear',
    color: 'Ivory',
    palette: 'Neutrals',
    styles: ['Romantic', 'Classic'],
    occasions: ['Wedding', 'Date night'],
    image: 'https://images.unsplash.com/photo-1535043934128-cf0b28d52f95?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: 'Soirée',
    stock: 12
  },
  {
    id: 'p29',
    name: 'Burnished Calf Leather Penny Loafers',
    brand: 'Forma Footwear',
    price: 2899,
    oldPrice: 3799,
    rating: 4.9,
    category: 'Shoes',
    gender: 'Men',
    slot: 'Footwear',
    color: 'Dark Brown',
    palette: 'Earth tones',
    styles: ['Classic', 'Minimal'],
    occasions: ['Work', 'Wedding', 'Date night'],
    image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Artisan Leather',
    stock: 15
  },
  {
    id: 'p30',
    name: 'Suede Chelsea Boots in Warm Taupe',
    brand: 'Forma Footwear',
    price: 3699,
    oldPrice: 4699,
    rating: 4.8,
    category: 'Shoes',
    gender: 'Unisex',
    slot: 'Footwear',
    color: 'Taupe',
    palette: 'Earth tones',
    styles: ['Classic', 'Streetwear'],
    occasions: ['Date night', 'Everyday', 'Work'],
    image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 11
  },

  // Additional Budget & Diverse Accessories
  {
    id: 'p31',
    name: 'Heavyweight Raw Canvas Shopper Tote',
    brand: 'Studio North',
    price: 399,
    oldPrice: 599,
    rating: 4.8,
    category: 'Bags',
    gender: 'Unisex',
    slot: 'Accessories',
    color: 'Natural',
    palette: 'Neutrals',
    styles: ['Minimal', 'Casual'],
    occasions: ['Everyday', 'College'],
    image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Under ₹400',
    stock: 60
  },
  {
    id: 'p32',
    name: 'Full-Grain Braided Leather Belt',
    brand: 'Common Ground',
    price: 499,
    oldPrice: 799,
    rating: 4.7,
    category: 'Accessories',
    gender: 'Unisex',
    slot: 'Accessories',
    color: 'Cognac',
    palette: 'Earth tones',
    styles: ['Classic', 'Minimal'],
    occasions: ['Everyday', 'Work'],
    image: 'https://images.unsplash.com/photo-1624222247344-550fb60583dc?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 45
  },
  {
    id: 'p33',
    name: 'Silk Habotai Printed Neck Scarf',
    brand: 'Atelier Edit',
    price: 599,
    oldPrice: 899,
    rating: 4.8,
    category: 'Accessories',
    gender: 'Women',
    slot: 'Accessories',
    color: 'Terracotta',
    palette: 'Soft pastels',
    styles: ['Romantic', 'Classic'],
    occasions: ['Date night', 'Wedding', 'Work'],
    image: 'https://images.unsplash.com/photo-1601924994987-69e26d50dc26?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 30
  },
  {
    id: 'p34',
    name: 'Geometric Wireframe Reading Glasses',
    brand: 'Hour & Form',
    price: 899,
    oldPrice: 1299,
    rating: 4.7,
    category: 'Accessories',
    gender: 'Unisex',
    slot: 'Accessories',
    color: 'Gold',
    palette: 'Neutrals',
    styles: ['Classic', 'Minimal'],
    occasions: ['Work', 'College'],
    image: 'https://images.unsplash.com/photo-1591076482161-42ce6da69f67?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: null,
    stock: 25
  },
  {
    id: 'p35',
    name: 'Half-Moon Leather Crescent Sling',
    brand: 'Maison Studio',
    price: 1699,
    oldPrice: 2299,
    rating: 4.9,
    category: 'Bags',
    gender: 'Women',
    slot: 'Accessories',
    color: 'Caramel',
    palette: 'Earth tones',
    styles: ['Minimal', 'Romantic'],
    occasions: ['Date night', 'Everyday'],
    image: 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=750&q=80',
    featured: false,
    tag: 'Trending',
    stock: 15
  },
  {
    id: 'p36',
    name: 'Chronograph Minimal Steel Watch 40mm',
    brand: 'Hour & Form',
    price: 2699,
    oldPrice: 3599,
    rating: 4.9,
    category: 'Watches',
    gender: 'Unisex',
    slot: 'Accessories',
    color: 'Matte Black',
    palette: 'Monochrome',
    styles: ['Classic', 'Minimal'],
    occasions: ['Work', 'Wedding', 'Date night'],
    image: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=750&q=80',
    featured: true,
    tag: 'Chronograph',
    stock: 14
  }
];

let orders: Order[] = [
  {
    id: 'ORD-2026-981',
    customerName: 'Tara Sen',
    customerEmail: 'tara.sen@example.com',
    customerPhone: '+91 98201 54321',
    deliveryAddress: 'Flat 302, Green Glen Layout, Bellandur, Bengaluru - 560103',
    items: [
      { id: 'p1', name: 'Everyday Relaxed Linen Shirt', price: 1899, quantity: 1, slot: 'Topwear' },
      { id: 'p5', name: 'Pleated High-Waist Linen Trouser', price: 1950, quantity: 1, slot: 'Bottomwear' }
    ],
    subtotal: 3849,
    shipping: 0,
    total: 3849,
    status: 'Processing',
    paymentMode: 'UPI (Google Pay)',
    createdAt: '2026-11-10T14:22:00Z'
  },
  {
    id: 'ORD-2026-980',
    customerName: 'Rohan Varma',
    customerEmail: 'rohan.v@example.com',
    customerPhone: '+91 98450 11223',
    deliveryAddress: '88, 5th Cross, Lavelle Road, Bengaluru - 560001',
    items: [
      { id: 'p3', name: 'Suede Low-Top Court Trainers', price: 2499, quantity: 1, slot: 'Footwear' }
    ],
    subtotal: 2499,
    shipping: 0,
    total: 2499,
    status: 'Dispatched',
    paymentMode: 'Credit Card',
    createdAt: '2026-11-09T18:05:00Z'
  },
  {
    id: 'ORD-2026-979',
    customerName: 'Ananya Roy',
    customerEmail: 'ananya.roy@example.com',
    customerPhone: '+91 99100 88776',
    deliveryAddress: 'C-14, Defence Colony, New Delhi - 110024',
    items: [
      { id: 'p2', name: 'Structure Leather Shoulder Bag', price: 2199, quantity: 1, slot: 'Accessories' },
      { id: 'p4', name: 'Bauhaus Minimalist Watch 38mm', price: 1799, quantity: 1, slot: 'Accessories' }
    ],
    subtotal: 3998,
    shipping: 0,
    total: 3998,
    status: 'Delivered',
    paymentMode: 'UPI',
    createdAt: '2026-11-08T11:40:00Z'
  },
  {
    id: 'ORD-2026-978',
    customerName: 'Vikram Joshi',
    customerEmail: 'vikram.j@example.com',
    customerPhone: '+91 97690 33445',
    deliveryAddress: 'Sea Face Towers, Worli, Mumbai - 400018',
    items: [
      { id: 'p6', name: 'Organic Heavyweight Crew Tee', price: 899, quantity: 2, slot: 'Topwear' },
      { id: 'p7', name: 'Vintage Straight Raw Denim', price: 1899, quantity: 1, slot: 'Bottomwear' }
    ],
    subtotal: 3697,
    shipping: 0,
    total: 3697,
    status: 'Delivered',
    paymentMode: 'Net Banking',
    createdAt: '2026-11-07T09:15:00Z'
  }
];

let serviceProviders: ServiceProvider[] = [
  {
    id: 's1',
    name: 'Indiranagar Master Tailors',
    category: 'Tailoring',
    city: 'Bengaluru',
    area: '100ft Road, Indiranagar',
    pin: '560038',
    rating: 4.9,
    priceRange: 'From ₹249',
    icon: 'scissors',
    desc: 'Bespoke tailoring, dress alterations, trouser tapering, and suit restructuring with 48h turnaround.',
    pickup: true,
    contactEmail: 'indiranagar.tailor@example.com',
    contactPhone: '+91 98451 90001',
    completedJobsCount: 142,
    totalEarnings: 48900
  },
  {
    id: 's2',
    name: 'Koramangala Sole & Cobbler Lab',
    category: 'Shoe repair',
    city: 'Bengaluru',
    area: '4th Block, Koramangala',
    pin: '560034',
    rating: 4.8,
    priceRange: 'From ₹299',
    icon: 'shoe',
    desc: 'Sole replacement, luxury sneaker deep clean, leather restoration, and heel reinforcement.',
    pickup: true,
    contactEmail: 'koramangala.cobbler@example.com',
    contactPhone: '+91 98451 90002',
    completedJobsCount: 198,
    totalEarnings: 64200
  },
  {
    id: 's3',
    name: 'The Leather Craft & Bag Clinic',
    category: 'Bag repair',
    city: 'Mumbai',
    area: 'Pali Hill, Bandra West',
    pin: '400050',
    rating: 4.9,
    priceRange: 'From ₹499',
    icon: 'bag',
    desc: 'Handbag strap stitching, zipper replacement, luxury leather conditioning and recolouring.',
    pickup: true,
    contactEmail: 'bandra.bags@example.com',
    contactPhone: '+91 98200 80003',
    completedJobsCount: 89,
    totalEarnings: 52100
  },
  {
    id: 's4',
    name: 'Precision Horology Works',
    category: 'Watch repair',
    city: 'Bengaluru',
    area: 'Jayanagar 4th T Block',
    pin: '560041',
    rating: 4.8,
    priceRange: 'From ₹199',
    icon: 'watch',
    desc: 'Swiss mechanism diagnostic, crystal replacement, waterproof gasket testing and vintage strap fittings.',
    pickup: false,
    contactEmail: 'jayanagar.horology@example.com',
    contactPhone: '+91 98451 90004',
    completedJobsCount: 114,
    totalEarnings: 33600
  },
  {
    id: 's5',
    name: 'Hauz Khas Alteration Atelier',
    category: 'Tailoring',
    city: 'Delhi',
    area: 'Hauz Khas Village',
    pin: '110016',
    rating: 4.8,
    priceRange: 'From ₹299',
    icon: 'scissors',
    desc: 'Occasion and wedding outfit refits, lehenga resizing, and precision denim hemming.',
    pickup: true,
    contactEmail: 'hauzkhas.tailor@example.com',
    contactPhone: '+91 98110 70005',
    completedJobsCount: 167,
    totalEarnings: 59400
  },
  {
    id: 's6',
    name: 'Heritage Leather Crafts',
    category: 'Bag repair',
    city: 'Delhi',
    area: 'Connaught Place',
    pin: '110001',
    rating: 4.7,
    priceRange: 'From ₹399',
    icon: 'bag',
    desc: 'Tote & duffle reinforcement, hardware replating, edge dye restoration for timeless heirlooms.',
    pickup: false,
    contactEmail: 'cp.leather@example.com',
    contactPhone: '+91 98110 70006',
    completedJobsCount: 76,
    totalEarnings: 36800
  }
];

let serviceBookings: ServiceBooking[] = [
  {
    id: 'BK-9021',
    providerId: 's1',
    providerName: 'Indiranagar Master Tailors',
    category: 'Tailoring',
    customerName: 'Arjun Mehta',
    customerEmail: 'arjun.mehta@example.com',
    customerPhone: '+91 98765 43210',
    customerAddress: '402, Lotus Residency, 12th Main, Indiranagar, Bengaluru - 560038',
    serviceNotes: 'Trouser tapering by 1.2 inches and button restitching on ivory linen shirt',
    preferredDate: '2026-11-14',
    serviceType: 'Doorstep Pickup & Return',
    status: 'In-Progress / Crafting',
    cost: 349,
    createdAt: '2026-11-10T10:30:00Z',
    providerNotes: 'Garment picked up. Master cutter scheduled for hemming.'
  },
  {
    id: 'BK-9022',
    providerId: 's2',
    providerName: 'Koramangala Sole & Cobbler Lab',
    category: 'Shoe repair',
    customerName: 'Priya Sharma',
    customerEmail: 'priya.s@example.com',
    customerPhone: '+91 98210 99887',
    customerAddress: '15th Main, 4th Block, Koramangala, Bengaluru',
    serviceNotes: 'Suede cleaning & protective water-repellent coating for court sneakers',
    preferredDate: '2026-11-15',
    serviceType: 'Doorstep Pickup & Return',
    status: 'Pickup Scheduled',
    cost: 499,
    createdAt: '2026-11-11T08:15:00Z',
    providerNotes: 'Courier dispatched for pickup window 10am-12pm.'
  },
  {
    id: 'BK-9020',
    providerId: 's1',
    providerName: 'Indiranagar Master Tailors',
    category: 'Tailoring',
    customerName: 'Karan Grover',
    customerEmail: 'karan.g@example.com',
    customerPhone: '+91 98440 22334',
    customerAddress: 'Doopanahalli, Indiranagar, Bengaluru',
    serviceNotes: 'Blazer sleeve shortening and lapel pressing',
    preferredDate: '2026-11-09',
    serviceType: 'Direct Studio Drop-off',
    status: 'Completed',
    cost: 599,
    createdAt: '2026-11-08T15:20:00Z',
    providerNotes: 'Finished and handed over to customer. Signed acknowledgment.'
  }
];

// Helper: Validation utilities
function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validatePhone(phone: string): boolean {
  return /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/.test(phone.replace(/\s+/g, ''));
}

// ==========================================
// API ROUTES
// ==========================================

// The current browser app uses Firebase for products, orders, bookings and analytics.
// Disable the old in-memory endpoints so they cannot be modified without authentication.
app.use(['/api/products', '/api/orders', '/api/analytics', '/api/services', '/api/bookings'], (_req, res) => {
  res.status(410).json({ success: false, message: 'Legacy in-memory endpoint disabled. Use the authenticated Firebase integration.' });
});

// 1. Legacy Products API (disabled by middleware above; retained for migration reference)
app.get('/api/products', (req, res) => {
  const { category, gender, search, under2000, sort, slot } = req.query;
  let result = [...products];

  if (category && category !== 'All') {
    if (category === 'Women' || category === 'Men') {
      result = result.filter(p => p.gender === category || p.gender === 'Unisex');
    } else {
      result = result.filter(p => p.category.toLowerCase() === (category as string).toLowerCase());
    }
  }

  if (slot && slot !== 'All') {
    result = result.filter(p => p.slot === slot);
  }

  if (search) {
    const q = (search as string).toLowerCase().trim();
    result = result.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.brand.toLowerCase().includes(q) ||
      p.color.toLowerCase().includes(q) ||
      p.styles.some(s => s.toLowerCase().includes(q))
    );
  }

  if (under2000 === 'true') {
    result = result.filter(p => p.price <= 2000);
  }

  if (sort === 'price-asc') {
    result.sort((a, b) => a.price - b.price);
  } else if (sort === 'price-desc') {
    result.sort((a, b) => b.price - a.price);
  } else if (sort === 'rating') {
    result.sort((a, b) => b.rating - a.rating);
  } else {
    result.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
  }

  res.json({ success: true, count: result.length, data: result });
});

// Add Product (Admin) with Dynamic Validation
app.post('/api/products', (req, res) => {
  const { name, brand, price, category, gender, slot, color, palette, styles, occasions, image, stock, featured, tag } = req.body;

  const errors: Record<string, string> = {};
  if (!name || typeof name !== 'string' || name.trim().length < 3) {
    errors.name = 'Product title must be at least 3 characters long.';
  }
  if (!brand || typeof brand !== 'string' || brand.trim().length < 2) {
    errors.brand = 'Brand name is required (min 2 characters).';
  }
  if (!price || typeof price !== 'number' || price <= 0) {
    errors.price = 'Valid positive price in ₹ is required.';
  }
  if (!category || typeof category !== 'string') {
    errors.category = 'Category selection is required.';
  }
  if (!slot || !['Topwear', 'Bottomwear', 'Footwear', 'Accessories'].includes(slot)) {
    errors.slot = 'Valid fashion slot (Topwear, Bottomwear, Footwear, Accessories) is required.';
  }
  if (!color || color.trim().length === 0) {
    errors.color = 'Primary colour is required.';
  }
  if (!image || typeof image !== 'string' || !image.startsWith('http')) {
    errors.image = 'A valid HTTP/HTTPS image URL is required.';
  }

  if (Object.keys(errors).length > 0) {
    res.status(400).json({ success: false, errors, message: 'Form validation failed' });
    return;
  }

  const newProduct: Product = {
    id: `p-${Date.now()}`,
    name: name.trim(),
    brand: brand.trim(),
    price: Math.round(price),
    oldPrice: req.body.oldPrice ? Math.round(req.body.oldPrice) : undefined,
    rating: 4.8,
    category: category.trim(),
    gender: gender || 'Unisex',
    slot,
    color: color.trim(),
    palette: palette || 'Neutrals',
    styles: Array.isArray(styles) && styles.length ? styles : ['Minimal', 'Casual'],
    occasions: Array.isArray(occasions) && occasions.length ? occasions : ['Everyday'],
    image: image.trim(),
    featured: Boolean(featured),
    tag: tag ? tag.trim() : null,
    stock: typeof stock === 'number' && stock >= 0 ? stock : 15
  };

  products.unshift(newProduct);
  res.status(201).json({ success: true, message: 'Product added successfully', data: newProduct });
});

// Update Product (Admin)
app.put('/api/products/:id', (req, res) => {
  const { id } = req.params;
  const index = products.findIndex(p => p.id === id);
  if (index === -1) {
    res.status(404).json({ success: false, message: 'Product not found' });
    return;
  }

  const existing = products[index];
  const { name, brand, price, oldPrice, stock, featured, tag, slot, category, image } = req.body;

  products[index] = {
    ...existing,
    name: name !== undefined ? name : existing.name,
    brand: brand !== undefined ? brand : existing.brand,
    price: price !== undefined ? Number(price) : existing.price,
    oldPrice: oldPrice !== undefined ? Number(oldPrice) : existing.oldPrice,
    stock: stock !== undefined ? Number(stock) : existing.stock,
    featured: featured !== undefined ? Boolean(featured) : existing.featured,
    tag: tag !== undefined ? tag : existing.tag,
    slot: slot !== undefined ? slot : existing.slot,
    category: category !== undefined ? category : existing.category,
    image: image !== undefined ? image : existing.image
  };

  res.json({ success: true, message: 'Product updated successfully', data: products[index] });
});

// Delete Product (Admin)
app.delete('/api/products/:id', (req, res) => {
  const { id } = req.params;
  const initialLength = products.length;
  products = products.filter(p => p.id !== id);
  if (products.length === initialLength) {
    res.status(404).json({ success: false, message: 'Product not found' });
    return;
  }
  res.json({ success: true, message: 'Product deleted successfully' });
});

// 2. Orders & Real-time Sales API
app.get('/api/orders', (req, res) => {
  res.json({ success: true, count: orders.length, data: orders });
});

app.post('/api/orders', (req, res) => {
  const { customerName, customerEmail, customerPhone, deliveryAddress, items, paymentMode } = req.body;

  const errors: Record<string, string> = {};
  if (!customerName || customerName.trim().length < 2) {
    errors.customerName = 'Recipient name must be at least 2 characters.';
  }
  if (!customerEmail || !validateEmail(customerEmail)) {
    errors.customerEmail = 'Please provide a valid email address.';
  }
  if (!customerPhone || !validatePhone(customerPhone)) {
    errors.customerPhone = 'Please provide a valid 10-digit phone number.';
  }
  if (!deliveryAddress || deliveryAddress.trim().length < 10) {
    errors.deliveryAddress = 'Full delivery address with PIN code is required (min 10 characters).';
  }
  if (!Array.isArray(items) || items.length === 0) {
    errors.items = 'Order must contain at least one piece.';
  }

  if (Object.keys(errors).length > 0) {
    res.status(400).json({ success: false, errors, message: 'Order form validation failed' });
    return;
  }

  const subtotal = items.reduce((sum: number, item: OrderItem) => sum + (item.price * item.quantity), 0);
  const newOrder: Order = {
    id: `ORD-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    customerName: customerName.trim(),
    customerEmail: customerEmail.trim(),
    customerPhone: customerPhone.trim(),
    deliveryAddress: deliveryAddress.trim(),
    items,
    subtotal,
    shipping: 0,
    total: subtotal,
    status: 'Processing',
    paymentMode: paymentMode || 'UPI (Instant)',
    createdAt: new Date().toISOString()
  };

  // Adjust product stocks
  items.forEach((item: OrderItem) => {
    const prod = products.find(p => p.id === item.id);
    if (prod && prod.stock >= item.quantity) {
      prod.stock -= item.quantity;
    }
  });

  orders.unshift(newOrder);
  res.status(201).json({ success: true, message: 'Order placed successfully', data: newOrder });
});

app.patch('/api/orders/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const order = orders.find(o => o.id === id);
  if (!order) {
    res.status(404).json({ success: false, message: 'Order not found' });
    return;
  }
  if (!['Processing', 'Dispatched', 'Delivered', 'Cancelled'].includes(status)) {
    res.status(400).json({ success: false, message: 'Invalid order status' });
    return;
  }
  order.status = status;
  res.json({ success: true, message: `Order status updated to ${status}`, data: order });
});

// Real-time Sales Analytics API
app.get('/api/analytics', (req, res) => {
  const totalRevenue = orders.reduce((sum, o) => sum + (o.status !== 'Cancelled' ? o.total : 0), 0);
  const totalOrders = orders.filter(o => o.status !== 'Cancelled').length;
  const averageOrderValue = totalOrders > 0 ? Math.round(totalRevenue / totalOrders) : 0;

  // Breakdown by aesthetic/style from ordered products
  const aestheticCounts: Record<string, number> = {
    Minimal: 42,
    Classic: 28,
    Casual: 18,
    Streetwear: 8,
    Romantic: 4
  };

  // Hourly / Recent sales points for visualization
  const salesTrend = [
    { hour: '09:00', sales: 4200 },
    { hour: '11:00', sales: 8600 },
    { hour: '13:00', sales: 12400 },
    { hour: '15:00', sales: 19800 },
    { hour: '17:00', sales: 27900 },
    { hour: '19:00', sales: 34500 },
    { hour: '21:00', sales: totalRevenue }
  ];

  res.json({
    success: true,
    data: {
      totalRevenue,
      todayRevenue: Math.round(totalRevenue * 0.35),
      totalOrders,
      averageOrderValue,
      conversionRate: '3.42%',
      dispatchedCount: orders.filter(o => o.status === 'Dispatched').length,
      processingCount: orders.filter(o => o.status === 'Processing').length,
      deliveredCount: orders.filter(o => o.status === 'Delivered').length,
      aestheticCounts,
      salesTrend,
      recentOrders: orders.slice(0, 6)
    }
  });
});

// 3. Local Fashion Care Services API
app.get('/api/services', (req, res) => {
  const { city, category } = req.query;
  let result = [...serviceProviders];

  if (category && category !== 'All') {
    result = result.filter(s => s.category.toLowerCase() === (category as string).toLowerCase());
  }
  if (city) {
    const q = (city as string).toLowerCase().trim();
    result = result.filter(s =>
      s.city.toLowerCase().includes(q) ||
      s.area.toLowerCase().includes(q) ||
      s.pin.includes(q)
    );
  }

  res.json({ success: true, count: result.length, data: result });
});

// Service Provider login simulation / retrieval
app.post('/api/services/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !validateEmail(email)) {
    res.status(400).json({ success: false, message: 'Please provide a valid provider email.' });
    return;
  }
  if (!password || password.length < 6) {
    res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });
    return;
  }

  // Match provider by email or assign default provider for demo
  const provider = serviceProviders.find(p => p.contactEmail.toLowerCase() === email.toLowerCase()) || serviceProviders[0];
  res.json({
    success: true,
    message: `Welcome back, ${provider.name}`,
    data: provider
  });
});

// Bookings API
app.get('/api/bookings', (req, res) => {
  const { providerId, customerEmail } = req.query;
  let result = [...serviceBookings];

  if (providerId) {
    result = result.filter(b => b.providerId === providerId);
  }
  if (customerEmail) {
    result = result.filter(b => b.customerEmail.toLowerCase() === (customerEmail as string).toLowerCase());
  }

  res.json({ success: true, count: result.length, data: result });
});

app.post('/api/bookings', (req, res) => {
  const {
    providerId,
    customerName,
    customerEmail,
    customerPhone,
    customerAddress,
    serviceNotes,
    preferredDate,
    serviceType
  } = req.body;

  const errors: Record<string, string> = {};
  if (!providerId) errors.providerId = 'Service partner ID is required.';
  if (!customerName || customerName.trim().length < 2) errors.customerName = 'Customer name is required.';
  if (!customerEmail || !validateEmail(customerEmail)) errors.customerEmail = 'Valid email address is required.';
  if (!customerPhone || !validatePhone(customerPhone)) errors.customerPhone = 'Valid phone number is required.';
  if (!customerAddress || customerAddress.trim().length < 8) errors.customerAddress = 'Address is required for care pickup.';
  if (!serviceNotes || serviceNotes.trim().length < 5) errors.serviceNotes = 'Please describe the tailoring or care needed (min 5 chars).';
  if (!preferredDate) errors.preferredDate = 'Preferred appointment date is required.';

  if (Object.keys(errors).length > 0) {
    res.status(400).json({ success: false, errors, message: 'Booking validation failed' });
    return;
  }

  const provider = serviceProviders.find(p => p.id === providerId) || serviceProviders[0];

  const newBooking: ServiceBooking = {
    id: `BK-${Math.floor(1000 + Math.random() * 9000)}`,
    providerId: provider.id,
    providerName: provider.name,
    category: provider.category,
    customerName: customerName.trim(),
    customerEmail: customerEmail.trim(),
    customerPhone: customerPhone.trim(),
    customerAddress: customerAddress.trim(),
    serviceNotes: serviceNotes.trim(),
    preferredDate,
    serviceType: serviceType || 'Doorstep Pickup & Return',
    status: 'Pickup Scheduled',
    cost: provider.category === 'Tailoring' ? 349 : provider.category === 'Bag repair' ? 499 : 299,
    createdAt: new Date().toISOString(),
    providerNotes: 'Booking logged. Assigned to local technician queue.'
  };

  serviceBookings.unshift(newBooking);
  provider.totalEarnings += newBooking.cost;
  res.status(201).json({ success: true, message: 'Care booking confirmed!', data: newBooking });
});

// Update Booking Status & Provider Notes (Service Provider Dashboard)
app.patch('/api/bookings/:id/status', (req, res) => {
  const { id } = req.params;
  const { status, providerNotes } = req.body;

  const booking = serviceBookings.find(b => b.id === id);
  if (!booking) {
    res.status(404).json({ success: false, message: 'Booking not found' });
    return;
  }

  const validStatuses = [
    'Pickup Scheduled',
    'Received in Workshop',
    'In-Progress / Crafting',
    'Ready for Delivery',
    'Completed'
  ];

  if (status && !validStatuses.includes(status)) {
    res.status(400).json({ success: false, message: 'Invalid booking status' });
    return;
  }

  if (status) booking.status = status;
  if (providerNotes !== undefined) booking.providerNotes = providerNotes;

  // If completed, increment provider completedJobsCount
  if (status === 'Completed') {
    const provider = serviceProviders.find(p => p.id === booking.providerId);
    if (provider) provider.completedJobsCount += 1;
  }

  res.json({ success: true, message: `Booking status updated to ${booking.status}`, data: booking });
});

// 4. Stylist Quiz API
app.post('/api/stylist/recommend', limitAiRequests, async (req, res) => {
  const { occasion, budget, style, palette, gender } = req.body;
  const budgetNum = parseFloat(budget) || 7500;
  const requestedProducts = Array.isArray(req.body.products) ? req.body.products.slice(0, 100).filter((p: any) => p && typeof p.id === 'string' && typeof p.name === 'string' && Number.isFinite(Number(p.price)) && Number(p.price) >= 0 && typeof p.slot === 'string').map((p: any) => ({ ...p, price: Number(p.price), color: String(p.color || 'Neutral'), styles: Array.isArray(p.styles) ? p.styles : [], occasions: Array.isArray(p.occasions) ? p.occasions : [] })) : [];
  const catalogue = requestedProducts.length ? requestedProducts : products;

  const genderPool = catalogue.filter(p =>
    !gender || gender === 'Any' || p.gender === gender || p.gender === 'Unisex'
  );

  const poolTops = genderPool.filter(p => p.slot === 'Topwear');
  const poolBottoms = genderPool.filter(p => p.slot === 'Bottomwear');
  const poolShoes = genderPool.filter(p => p.slot === 'Footwear');
  const poolAccessories = genderPool.filter(p => p.slot === 'Accessories');

  const topsList = poolTops.length ? poolTops : products.filter(p => p.slot === 'Topwear');
  const bottomsList = poolBottoms.length ? poolBottoms : products.filter(p => p.slot === 'Bottomwear');
  const shoesList = poolShoes.length ? poolShoes : products.filter(p => p.slot === 'Footwear');
  const accessoriesList = poolAccessories.length ? poolAccessories : products.filter(p => p.slot === 'Accessories');

  const minTop = Math.min(...topsList.map(p => p.price));
  const minBottom = Math.min(...bottomsList.map(p => p.price));
  const minShoe = Math.min(...shoesList.map(p => p.price));
  const minAcc = Math.min(...accessoriesList.map(p => p.price));
  const minRequiredCost = minTop + minBottom + minShoe + minAcc;

  if (budgetNum < minRequiredCost) {
    const shortfall = minRequiredCost - budgetNum;
    res.json({
      success: false,
      canCreate: false,
      message: `A complete coordinated look requires a minimum of ₹${minRequiredCost.toLocaleString('en-IN')}. Please increase your budget by at least ₹${shortfall.toLocaleString('en-IN')}.`,
      givenBudget: budgetNum,
      minRequiredBudget: minRequiredCost,
      shortfall
    });
    return;
  }

  interface Combo {
    items: [Product, Product, Product, Product];
    cost: number;
    score: number;
  }

  const validCombos: Combo[] = [];

  for (const t of topsList) {
    for (const b of bottomsList) {
      if (t.price + b.price >= budgetNum) continue;
      for (const s of shoesList) {
        if (t.price + b.price + s.price >= budgetNum) continue;
        for (const a of accessoriesList) {
          const cost = t.price + b.price + s.price + a.price;
          if (cost <= budgetNum) {
            let score = 0;
            if (style && t.styles.includes(style)) score += 10;
            if (style && b.styles.includes(style)) score += 10;
            if (style && s.styles.includes(style)) score += 10;
            if (style && a.styles.includes(style)) score += 10;

            if (occasion && t.occasions.includes(occasion)) score += 8;
            if (occasion && b.occasions.includes(occasion)) score += 8;
            if (occasion && s.occasions.includes(occasion)) score += 8;
            if (occasion && a.occasions.includes(occasion)) score += 8;

            if (palette && t.palette === palette) score += 5;
            if (palette && b.palette === palette) score += 5;
            if (palette && s.palette === palette) score += 5;
            if (palette && a.palette === palette) score += 5;

            score += (cost / budgetNum) * 4;

            validCombos.push({ items: [t, b, s, a], cost, score });
          }
        }
      }
    }
  }

  if (validCombos.length === 0) {
    const shortfall = minRequiredCost - budgetNum;
    res.json({
      success: false,
      canCreate: false,
      message: `No combination found under ₹${budgetNum.toLocaleString('en-IN')}. Please increase your budget by at least ₹${shortfall.toLocaleString('en-IN')}.`,
      givenBudget: budgetNum,
      minRequiredBudget: minRequiredCost,
      shortfall
    });
    return;
  }

  validCombos.sort((x, y) => {
    if (y.score !== x.score) return y.score - x.score;
    return y.cost - x.cost;
  });

  const best = validCombos[0];
  const [top, bottom, foot, acc] = best.items;

  let editorialAdvice = `This ensemble balances clean tailoring with relaxed breathable textiles. Pair the ${String(top.color || 'neutral').toLowerCase()} ${top.name} with ${bottom.name} to anchor the ${style ? String(style).toLowerCase() : 'minimal'} aesthetic. Keep accessories understated.`;
  if (process.env.GEMINI_API_KEY) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const aiResponse = await ai.models.generateContent({
        model: process.env.GEMINI_MODEL || 'gemini-3.8-flash',
        contents: [{ role: 'user', parts: [{ text: `You are StyleSense AI, a fashion stylist for an Indian marketplace. In at most 65 words, explain why this outfit suits the customer's preferences. Occasion: ${occasion}; budget: INR ${budgetNum}; style: ${style}; palette: ${palette}; gender preference: ${gender}. Items: ${[top, bottom, foot, acc].map((item: any) => `${item.name}, ${item.color || 'neutral'}, INR ${item.price}`).join('; ')}. Do not invent item details or claim availability.` }] }]
      });
      if (aiResponse.text?.trim()) editorialAdvice = aiResponse.text.trim().slice(0, 700);
    } catch (error) {
      console.warn('Gemini recommendation explanation unavailable; using local styling advice.', error);
    }
  }

  res.json({
    success: true,
    canCreate: true,
    data: {
      occasion: occasion || 'Everyday Casual',
      style: style || 'Minimal',
      palette: palette || 'Neutrals',
      totalCost: best.cost,
      budget: budgetNum,
      withinBudget: true,
      savedAmount: budgetNum - best.cost,
      ensemble: [top, bottom, foot, acc],
      editorialAdvice
    }
  });
});

// 5. Stylist Chatbot API
app.post('/api/chat', limitAiRequests, async (req, res) => {
  const { message } = req.body;
  if (!message || typeof message !== 'string' || message.length > 1200) {
    res.status(400).json({ success: false, message: 'A message of 1–1200 characters is required.' });
    return;
  }

  // Use Gemini on the server when a key is configured. The key is never sent to the browser.
  if (process.env.GEMINI_API_KEY) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: process.env.GEMINI_MODEL || 'gemini-3.8-flash',
        contents: [{
          role: 'user',
          parts: [{
            text: `You are StyleSense AI, a practical fashion stylist for an Indian fashion marketplace. Give concise, helpful advice about outfit combinations, colours, occasions, wardrobe planning, fit, garment care and budget-conscious shopping. Use INR when mentioning prices. Do not claim a product is in stock unless the user provides that information. User message: ${message}`
          }]
        }]
      });
      const reply = response.text?.trim();
      if (reply) {
        res.json({ success: true, reply, provider: 'gemini' });
        return;
      }
    } catch (error) {
      console.error('Gemini chat request failed; using local fallback:', error);
    }
  }

  const q = message.toLowerCase();
  let reply = 'I love that aesthetic direction! Explore the AI Stylist Studio to assemble a coordinated look with budget tracking.';
  if (q.includes('college') || q.includes('campus')) {
    reply = 'For college wear, pair a heavyweight crew tee with straight denim and comfortable low-top trainers. Neutral colours make the pieces easy to reuse.';
  } else if (q.includes('wedding') || q.includes('party') || q.includes('reception')) {
    reply = 'For a wedding guest look, try tailored trousers, a refined shirt or blouse, understated accessories and polished footwear. Coordinate the palette with the event dress code.';
  } else if (q.includes('under') || q.includes('budget')) {
    reply = 'Start with versatile essentials: a neutral tee, a well-fitting trouser and simple footwear. Check the marketplace budget filter to keep the total within your limit.';
  } else if (q.includes('color') || q.includes('colour') || q.includes('black') || q.includes('earth')) {
    reply = 'Anchor a dark monochrome piece with soft earth tones such as olive, sand or warm taupe. Keep the number of strong colours limited for a balanced look.';
  } else if (q.includes('tailor') || q.includes('repair') || q.includes('care') || q.includes('service')) {
    reply = 'Open the Local Services section to browse tailoring, shoe, bag and watch-care partners, then submit a booking request.';
  }
  res.json({ success: true, reply, provider: 'fallback' });
});

// Configure Vite or Static Serving
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static('dist'));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve('dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`StyleSense AI backend server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
