# StyleSense AI — Firebase + free-tier integrations

This package continues the existing StyleSense AI HTML/CSS/JavaScript website. The original layout and styling are retained; the integration adds Firebase-backed customer data, a server-side Gemini stylist/chat endpoint, Cloudinary image uploads, weather-aware styling, and a Firestore-backed admin dashboard.

## Free-budget architecture

- **Firebase Spark:** email/password Authentication and Cloud Firestore. No billing account is needed for these selected services. Firestore remains subject to its free quotas.
- **Gemini Developer API:** `gemini-3.8-flash` is the default model. The free tier is limited by model/account quotas. The free-tier terms state that submitted content may be used to improve Google products; do not send passwords, payment details, or sensitive customer information.
- **Cloudinary Free:** wardrobe and product image uploads use an unsigned upload preset. The client contains only the cloud name and preset name, never the API secret. Restrict the preset to JPG/PNG/WEBP, a 5 MB maximum, no overwrite, and a fixed `stylesense` folder. Unsigned preset names are public, so monitor usage and rotate the preset if abused.
- **Open-Meteo:** current weather and geocoding for weather-aware outfit suggestions; no API key is required for the basic endpoint.
- No Google Maps, paid search grounding, paid image generation, Firebase Storage, payment gateway, or paid notification service is used.

## Implemented in this package

- Firebase Authentication: email/password registration, sign-in and sign-out.
- Cloud Firestore: customer profile, private app state (cart, wishlist, wardrobe, saved outfits), orders and care bookings.
- Cloudinary: wardrobe and admin product image uploads, with a 5 MB client-side file limit.
- Product catalogue: reads Firestore `products` when available; bundled sample products remain the fallback.
- Search, filters, cart and stylist recommendations use the loaded catalogue.
- Gemini-backed AI chat and Gemini-generated outfit explanation when `GEMINI_API_KEY` is configured; deterministic local fallback remains available.
- Weather-aware outfit suggestions using Open-Meteo.
- Firestore analytics events for product card clicks, add-to-cart, wishlist, stylist quiz, search, orders and bookings.
- Admin-only dashboard: recorded order value, orders, products, bookings, activity metrics, product create/delete and order-status updates.
- Legacy in-memory product/order/booking/analytics/service endpoints are disabled. The current browser app uses Firestore for these records.

## Important limitations (do not present these as completed production features)

- The virtual try-on is still an image preview/prototype, not a generated AI garment try-on.
- Checkout records a demo order. It does not charge a payment method, calculate trusted server-side prices, or integrate a payment gateway.
- The service provider catalogue still contains the supplied demo provider data. The map is a city-level OpenStreetMap link/preview; no unverified provider pins are shown.
- Analytics count recorded app events from the time tracking is enabled; they are not historical or independent third-party analytics.
- Browser push notifications / Firebase Cloud Messaging are not configured.
- The Express rate limiter is in-memory and intended only as a small demo safeguard. Use a persistent rate limiter and stronger abuse protection before public production deployment.

## 1. Configure Firebase (Spark plan)

1. Open Firebase Console and select the StyleSense AI project.
2. In **Project settings → Your apps**, verify all six `VITE_FIREBASE_*` values in `.env.example` against your actual Web App config. Replace them if they differ.
3. Enable **Authentication → Sign-in method → Email/Password**.
4. Create a **Cloud Firestore** database.
5. Keep the project on the **Spark** plan. Do not enable Firebase Storage; this package no longer uses it because Cloud Storage for Firebase requires Blaze billing.
6. Copy `.env.example` to `.env.local` and keep `.env.local` out of GitHub.
7. In **Firestore Database → Rules**, publish the contents of `firestore.rules`.

### Create an admin account

1. Register normally through the StyleSense AI website.
2. In Firebase Console → Firestore Database → Data, open `users` and then the document whose ID is that admin user's Firebase Authentication UID.
3. Change the `role` field from `customer` to `admin` using the Firebase Console as the project owner.
4. Sign out and sign in again in the website.

Normal users cannot change their own role through the website; Firestore rules preserve the role field on customer profile updates. Only the project owner should assign admin roles.

## 2. Configure Cloudinary Free image uploads

1. Create a free Cloudinary account: https://cloudinary.com/users/register/free
2. In the Cloudinary dashboard, copy the **Cloud name**.
3. Go to Settings → Upload → Upload presets and create an **unsigned** preset.
4. Configure the preset with a fixed `stylesense` folder, JPG/PNG/WEBP allowed formats, maximum file size 5 MB, and overwrite disabled. Do not permit arbitrary transformations or raw/video uploads for this project.
5. Add these values to `.env.local`:

```env
VITE_CLOUDINARY_CLOUD_NAME=your_cloud_name
VITE_CLOUDINARY_UPLOAD_PRESET=your_unsigned_preset_name
```

The upload preset is public by design. Do not add the Cloudinary API Secret to the frontend or any `VITE_` variable. An unsigned preset can be abused if shared widely; keep its restrictions tight and monitor the account's monthly credits.

## 3. Configure Gemini free tier (optional, recommended)

1. Open https://aistudio.google.com/apikey.
2. Create an API key using a project on the free tier. Do not link a billing account for this strict-budget setup.
3. Add the key to `.env.local`:

```env
GEMINI_API_KEY=your_gemini_api_key
GEMINI_MODEL=gemini-3.8-flash
```

4. Restart the server after changing environment variables.

The key is read only by `server.ts`; it is not exposed to browser JavaScript. The selected model and free-tier quota are subject to change. If Gemini is unavailable or the free quota is reached, the chatbot and stylist explanation fall back to local responses/ranking.

## 4. Run locally

Prerequisite: Node.js 20.19+ (or a compatible current Node release).

```bash
npm install
npm run dev
```

Open the local URL printed by the server (normally `http://localhost:3000`). Do not double-click `index.html`, because `/api` requests need the Express/Vite server.

## 5. Firestore data structure

- `users/{uid}` — customer profile and role (`customer` or owner-assigned `admin`).
- `users/{uid}/private/appState` — private cart, wishlist, wardrobe image URLs, saved outfits and preferences.
- `products/{productId}` — public product catalogue; admin-only create/update/delete.
- `orders/{orderId}` — customer orders with `uid`, line items, totals and status.
- `bookings/{bookingId}` — care bookings with `uid`, provider, date, notes and status.
- `analytics_events/{eventId}` — limited event type, customer UID and non-sensitive metadata; customers can create only their own events, admins can read.

## 6. Final verification checklist

- Register and sign in with a test customer account.
- Add an item to cart and wishlist; refresh and confirm private app state returns.
- Upload a wardrobe photo; confirm Cloudinary returns a secure image URL and the URL is saved in the private Firestore app state.
- Place a demo order and submit a care booking; verify documents in Firestore.
- Try a second customer account and verify it cannot read another customer's profile, app state, orders or bookings.
- Assign an admin role through Firebase Console; verify the dashboard loads live metrics, product creation/deletion and order-status updates.
- Check Firestore Rules Playground and Cloudinary usage before sharing the app publicly.
