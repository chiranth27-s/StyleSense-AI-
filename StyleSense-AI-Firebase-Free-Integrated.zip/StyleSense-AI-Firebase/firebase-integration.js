import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  addDoc,
  collection,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  updateDoc,
  deleteDoc
} from 'firebase/firestore';

// Values are from the Firebase configuration already present in the generated backend.
// Verify them against Firebase Console > Project settings > Your apps before deployment.
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyB0BvpvEBmeX6xH1OM0NMFBKJ7vJXyiufk',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'stylesense-ai-9c59f.firebaseapp.com',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'stylesense-ai-9c59f',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'stylesense-ai-9c59f.firebasestorage.app',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '65178120662',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:65178120662:web:ff0db7bd80a469485c3477'
};

let app;
let auth;
let db;
let cloudReady = false;
let currentUser = null;
let persistQueue = Promise.resolve();

try {
  app = getApps().length ? getApp() : initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
} catch (error) {
  console.error('Firebase initialization failed:', error);
  window.setTimeout(() => window.showToast?.('Firebase setup failed. Check the Firebase config.', true), 0);
}

const appStateRef = (uid) => doc(db, 'users', uid, 'private', 'appState');

function getAppStatePayload() {
  const state = window.stylesenseState;
  return {
    cart: state.cart || [],
    wishlist: state.wishlist || [],
    wardrobe: state.wardrobe || [],
    savedOutfits: state.savedOutfits || [],
    serviceBookings: state.serviceBookings || [],
    user: {
      name: state.user?.name || currentUser?.displayName || '',
      email: currentUser?.email || state.user?.email || '',
      phone: state.user?.phone || '',
      preferredStyle: state.user?.preferredStyle || 'Minimal',
      palette: state.user?.palette || '',
      lastOccasion: state.user?.lastOccasion || '',
      addresses: state.user?.addresses || []
    },
    updatedAt: new Date().toISOString()
  };
}

async function loadUserCloudData(user) {
  const state = window.stylesenseState;
  const profileRef = doc(db, 'users', user.uid);
  const profileSnap = await getDoc(profileRef);
  const profile = profileSnap.exists() ? profileSnap.data() : {};

  state.user = {
    name: profile.name || user.displayName || 'StyleSense Member',
    email: user.email || '',
    phone: profile.phone || '',
    preferredStyle: profile.preferredStyle || 'Minimal',
    palette: profile.palette || '',
    lastOccasion: profile.lastOccasion || '',
    addresses: Array.isArray(profile.addresses) ? profile.addresses : [{ id: 'home', label: 'Home', text: '' }]
  };

  if (!profileSnap.exists()) {
    await setDoc(profileRef, {
      uid: user.uid,
      name: state.user.name,
      email: state.user.email,
      phone: '',
      role: 'customer',
      createdAt: serverTimestamp()
    }, { merge: true });
  }

  const appStateSnap = await getDoc(appStateRef(user.uid));
  if (appStateSnap.exists()) {
    const saved = appStateSnap.data();
    if (Array.isArray(saved.cart)) state.cart = saved.cart;
    if (Array.isArray(saved.wishlist)) state.wishlist = saved.wishlist;
    if (Array.isArray(saved.wardrobe)) state.wardrobe = saved.wardrobe;
    if (Array.isArray(saved.savedOutfits)) state.savedOutfits = saved.savedOutfits;
    if (Array.isArray(saved.serviceBookings)) state.serviceBookings = saved.serviceBookings;
    if (saved.user) state.user = { ...state.user, ...saved.user, email: user.email || saved.user.email };
  }

  const [ordersSnap, bookingsSnap] = await Promise.all([
    getDocs(query(collection(db, 'orders'), where('uid', '==', user.uid), limit(50))),
    getDocs(query(collection(db, 'bookings'), where('uid', '==', user.uid), limit(50)))
  ]);

  state.orders = ordersSnap.docs.map((item) => {
    const order = item.data();
    return {
      id: item.id,
      date: order.createdAt?.toDate ? order.createdAt.toDate().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : new Date(order.createdAt || Date.now()).toLocaleDateString('en-IN'),
      total: Number(order.total || 0),
      status: order.status || 'Processing',
      items: (order.items || []).map((entry) => `${entry.name} (x${entry.quantity})`)
    };
  });
  state.serviceBookings = bookingsSnap.docs.map((item) => {
    const booking = item.data();
    return {
      id: item.id,
      serviceName: booking.providerName || 'Fashion Care Partner',
      category: booking.category || 'Fashion Care',
      date: booking.preferredDate || '',
      status: booking.status || 'Pickup Scheduled',
      cost: `₹${Number(booking.cost || 0)}`
    };
  });

  cloudReady = true;
  window.stylesenseState = state;
  window.firebaseUser = user;
  const label = document.getElementById('account-btn-label');
  if (label) label.textContent = (user.displayName || user.email?.split('@')[0] || 'My Account').slice(0, 18);
  window.renderWardrobe?.();
  window.updateCartUI?.();
  window.applyFilters?.();
}

window.firebasePersistAppState = function firebasePersistAppState() {
  if (!currentUser || !cloudReady || !db) return Promise.resolve();
  const uid = currentUser.uid;
  const payload = getAppStatePayload();
  persistQueue = persistQueue.then(() => setDoc(appStateRef(uid), payload, { merge: true }))
    .catch((error) => console.error('Could not sync account data:', error));
  return persistQueue;
};

window.firebaseCreateOrder = async function firebaseCreateOrder(payload) {
  if (!currentUser) throw new Error('Please sign in to place an order.');
  const record = {
    ...payload,
    uid: currentUser.uid,
    customerEmail: currentUser.email || payload.customerEmail,
    status: 'Processing',
    createdAt: serverTimestamp()
  };
  const result = await addDoc(collection(db, 'orders'), record);
  return { ...payload, ...record, id: result.id, createdAt: new Date().toISOString() };
};

window.firebaseCreateBooking = async function firebaseCreateBooking(payload) {
  if (!currentUser) throw new Error('Please sign in to book a service.');
  const record = {
    ...payload,
    uid: currentUser.uid,
    customerEmail: currentUser.email || payload.customerEmail,
    status: 'Pickup Scheduled',
    createdAt: serverTimestamp()
  };
  const result = await addDoc(collection(db, 'bookings'), record);
  return { ...payload, ...record, id: result.id };
};

// Cloudinary unsigned uploads keep image hosting on a no-card free plan.
// Only the cloud name and restricted unsigned preset are exposed in the browser;
// never place a Cloudinary API secret in VITE_ variables.
async function uploadImageToCloudinary(file) {
  if (!currentUser) throw new Error('Please sign in before uploading an image.');
  if (!file || !/^image\/(jpeg|png|webp)$/.test(file.type)) throw new Error('Choose a JPG, PNG or WEBP image.');
  if (file.size > 5 * 1024 * 1024) throw new Error('Image must be smaller than 5 MB.');
  const cloudName = import.meta.env.VITE_CLOUDINARY_CLOUD_NAME;
  const uploadPreset = import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET;
  if (!cloudName || !uploadPreset) throw new Error('Image uploads are not configured. Add the Cloudinary cloud name and unsigned upload preset to .env.local.');
  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', uploadPreset);
  const response = await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloudName)}/image/upload`, { method: 'POST', body: formData });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.secure_url) {
    console.error('Cloudinary upload failed:', result);
    throw new Error(result.error?.message || 'Could not upload the image. Check your Cloudinary upload preset.');
  }
  return result.secure_url;
}
window.firebaseUploadWardrobeImage = uploadImageToCloudinary;
window.firebaseUploadProductImage = uploadImageToCloudinary;

window.firebaseTrackEvent = async function firebaseTrackEvent(eventType, metadata = {}) {
  if (!currentUser || !db) return;
  const allowed = ['product_click', 'add_to_cart', 'add_to_wishlist', 'stylist_quiz', 'order_created', 'booking_created', 'search'];
  if (!allowed.includes(eventType)) return;
  const safeMetadata = {};
  ['productId', 'category', 'slot', 'style', 'occasion', 'queryLength', 'value'].forEach((key) => {
    if (metadata[key] !== undefined && ['string', 'number'].includes(typeof metadata[key])) {
      safeMetadata[key] = typeof metadata[key] === 'string' ? metadata[key].slice(0, 80) : metadata[key];
    }
  });
  try {
    await addDoc(collection(db, 'analytics_events'), {
      uid: currentUser.uid,
      eventType,
      metadata: safeMetadata,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    console.warn('Analytics event was not saved:', error);
  }
};

window.firebaseLoadAdminDashboard = async function firebaseLoadAdminDashboard() {
  if (!currentUser) throw new Error('Please sign in first.');
  const profileSnap = await getDoc(doc(db, 'users', currentUser.uid));
  if (!profileSnap.exists() || profileSnap.data().role !== 'admin') {
    throw new Error('This account does not have admin access. Ask the project owner to grant admin access in Firebase Console.');
  }
  const [ordersSnap, productsSnap, eventsSnap, bookingsSnap] = await Promise.all([
    getDocs(query(collection(db, 'orders'), orderBy('createdAt', 'desc'), limit(100))),
    getDocs(query(collection(db, 'products'), limit(100))),
    getDocs(query(collection(db, 'analytics_events'), orderBy('createdAt', 'desc'), limit(1000))),
    getDocs(query(collection(db, 'bookings'), limit(100)))
  ]);
  const orders = ordersSnap.docs.map((item) => ({ id: item.id, ...item.data() }));
  const products = productsSnap.docs.map((item) => ({ id: item.id, ...item.data() }));
  const events = eventsSnap.docs.map((item) => ({ id: item.id, ...item.data() }));
  const bookings = bookingsSnap.docs.map((item) => ({ id: item.id, ...item.data() }));
  const revenue = orders.filter((order) => order.status !== 'Cancelled').reduce((sum, order) => sum + Number(order.total || 0), 0);
  const countEvents = (name) => events.filter((event) => event.eventType === name).length;
  return {
    orders: orders.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0)).slice(0, 20),
    products,
    metrics: {
      revenue,
      orders: orders.length,
      products: products.length,
      bookings: bookings.length,
      productClicks: countEvents('product_click'),
      addToCart: countEvents('add_to_cart'),
      wishlistAdds: countEvents('add_to_wishlist'),
      stylistUses: countEvents('stylist_quiz'),
      searches: countEvents('search')
    }
  };
};

window.firebaseAdminUpdateOrderStatus = async function firebaseAdminUpdateOrderStatus(orderId, status) {
  if (!currentUser) throw new Error('Admin sign-in required.');
  const allowed = ['Processing', 'Dispatched', 'Delivered', 'Cancelled'];
  if (!allowed.includes(status)) throw new Error('Invalid order status.');
  await updateDoc(doc(db, 'orders', orderId), { status, updatedAt: serverTimestamp() });
};

window.firebaseAdminCreateProduct = async function firebaseAdminCreateProduct(product) {
  if (!currentUser) throw new Error('Admin sign-in required.');
  const record = {
    ...product,
    rating: Number(product.rating || 4.5),
    oldPrice: null,
    featured: false,
    tag: null,
    stock: Number(product.stock || 0),
    styles: Array.isArray(product.styles) ? product.styles : ['Minimal'],
    occasions: Array.isArray(product.occasions) ? product.occasions : ['Everyday'],
    createdAt: serverTimestamp()
  };
  const result = await addDoc(collection(db, 'products'), record);
  const saved = { ...record, id: result.id, createdAt: new Date().toISOString() };
  window.stylesenseProducts?.push(saved);
  window.applyFilters?.();
  return saved;
};

window.firebaseAdminDeleteProduct = async function firebaseAdminDeleteProduct(productId) {
  if (!currentUser) throw new Error('Admin sign-in required.');
  await deleteDoc(doc(db, 'products', productId));
  if (window.stylesenseProducts) {
    const index = window.stylesenseProducts.findIndex((product) => product.id === productId);
    if (index >= 0) window.stylesenseProducts.splice(index, 1);
  }
  window.applyFilters?.();
};

window.openAuthModal = function openAuthModal(mode = 'login') {
  document.getElementById('firebase-auth-overlay').hidden = false;
  document.body.classList.add('locked');
  window.setAuthMode(mode);
};
window.closeAuthModal = function closeAuthModal() {
  document.getElementById('firebase-auth-overlay').hidden = true;
  document.body.classList.remove('locked');
};
window.openAccountOrAuth = function openAccountOrAuth() {
  if (currentUser) window.openAccountModal('profile');
  else window.openAuthModal('login');
};
window.setAuthMode = function setAuthMode(mode) {
  const register = mode === 'register';
  document.getElementById('auth-name-field').hidden = !register;
  document.getElementById('auth-display-name').required = register;
  document.getElementById('auth-password').autocomplete = register ? 'new-password' : 'current-password';
  document.getElementById('auth-login-tab').classList.toggle('active', !register);
  document.getElementById('auth-register-tab').classList.toggle('active', register);
  document.getElementById('auth-submit-btn').textContent = register ? 'Create Account' : 'Sign In';
  document.getElementById('firebase-auth-title').textContent = register ? 'Create your StyleSense account' : 'Welcome back to StyleSense';
  document.getElementById('auth-status').textContent = '';
  document.getElementById('firebase-auth-form').dataset.mode = mode;
};
window.handleFirebaseAuthSubmit = async function handleFirebaseAuthSubmit(event) {
  event.preventDefault();
  if (!auth) {
    document.getElementById('auth-status').textContent = 'Firebase is not initialized. Check your project configuration.';
    return;
  }
  const form = event.currentTarget;
  const mode = form.dataset.mode || 'login';
  const email = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-password').value;
  const name = document.getElementById('auth-display-name').value.trim();
  const button = document.getElementById('auth-submit-btn');
  const status = document.getElementById('auth-status');
  button.disabled = true;
  status.textContent = mode === 'register' ? 'Creating your account…' : 'Signing you in…';
  try {
    if (mode === 'register') {
      const credential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(credential.user, { displayName: name });
      await setDoc(doc(db, 'users', credential.user.uid), {
        uid: credential.user.uid,
        name,
        email,
        phone: '',
        role: 'customer',
        createdAt: serverTimestamp()
      }, { merge: true });
    } else {
      await signInWithEmailAndPassword(auth, email, password);
    }
    status.textContent = 'Success. Loading your account…';
    window.closeAuthModal();
    window.showToast?.(mode === 'register' ? 'Your StyleSense account has been created.' : 'Signed in successfully.');
  } catch (error) {
    console.error(error);
    const messages = {
      'auth/email-already-in-use': 'An account already exists with this email.',
      'auth/invalid-email': 'Enter a valid email address.',
      'auth/invalid-credential': 'Email or password is incorrect.',
      'auth/weak-password': 'Use a password with at least 6 characters.',
      'auth/network-request-failed': 'Network error. Check your internet connection.'
    };
    status.textContent = messages[error.code] || error.message || 'Authentication failed.';
  } finally {
    button.disabled = false;
  }
};
window.saveAccountProfile = async function saveAccountProfile() {
  if (!currentUser) return window.openAuthModal('login');
  const state = window.stylesenseState;
  const name = document.getElementById('account-profile-name').value.trim();
  const phone = document.getElementById('account-profile-phone').value.trim();
  const preferredStyle = document.getElementById('account-profile-style').value.trim() || 'Minimal';
  const address = document.getElementById('account-profile-address').value.trim();
  if (!name) return window.showToast?.('Please enter your name.', true);
  state.user.name = name;
  state.user.phone = phone;
  state.user.preferredStyle = preferredStyle;
  state.user.addresses = [{ id: 'home', label: 'Home', text: address }];
  try {
    await setDoc(doc(db, 'users', currentUser.uid), {
      name, phone, preferredStyle,
      addresses: state.user.addresses
    }, { merge: true });
    if (auth.currentUser && auth.currentUser.displayName !== name) {
      await updateProfile(auth.currentUser, { displayName: name });
    }
    await window.firebasePersistAppState();
    const label = document.getElementById('account-btn-label');
    if (label) label.textContent = name.slice(0, 18);
    window.showToast?.('Your profile has been saved to Firebase.');
  } catch (error) {
    console.error(error);
    window.showToast?.(error.message || 'Could not save your profile.', true);
  }
};

window.firebaseSignOutUser = async function firebaseSignOutUser() {
  if (!auth) return;
  await signOut(auth);
  window.closeAccountModal?.();
  window.showToast?.('You have signed out.');
};

// Replace the demo account entry point with an authenticated account gate.
window.openAccountModal = function openAccountModal(initialTab = 'profile') {
  if (!currentUser) {
    window.openAuthModal('login');
    return;
  }
  window.renderAccountContent(initialTab);
  document.getElementById('account-modal-overlay').hidden = false;
  document.body.classList.add('locked');
};

// Prefer Firestore catalog data when an administrator has populated the products collection.
async function loadFirestoreProducts() {
  try {
    const snapshot = await getDocs(query(collection(db, 'products'), limit(100)));
    if (!snapshot.empty) {
      const products = snapshot.docs.map((item) => {
        const product = item.data();
        return {
          ...product,
          id: item.id,
          brand: product.brand || 'StyleSense Edit',
          category: product.category || 'Clothing',
          gender: product.gender || 'Unisex',
          slot: product.slot || 'Topwear',
          color: product.color || 'Neutral',
          palette: product.palette || product.color || 'Neutrals',
          price: Number(product.price || 0),
          rating: Number(product.rating || 4.5),
          stock: Number(product.stock || 0),
          image: product.image || '',
          styles: Array.isArray(product.styles) ? product.styles : ['Minimal'],
          occasions: Array.isArray(product.occasions) ? product.occasions : ['Everyday'],
          featured: Boolean(product.featured)
        };
      });
      window.stylesenseProducts.splice(0, window.stylesenseProducts.length, ...products);
      window.renderCategoryTabs?.();
      window.applyFilters?.();
    }
  } catch (error) {
    console.warn('Using bundled catalogue until Firestore products are available:', error);
  }
}

if (auth) {
  onAuthStateChanged(auth, async (user) => {
    currentUser = user;
    window.firebaseUser = user;
    cloudReady = false;
    if (user) {
      try {
        await loadUserCloudData(user);
        window.showToast?.(`Welcome, ${window.stylesenseState.user.name}!`);
      } catch (error) {
        console.error('Could not load Firebase account data:', error);
        window.showToast?.('Signed in, but account data could not be loaded. Check Firestore rules.', true);
      }
    } else {
      const state = window.stylesenseState;
      state.user = { name: 'Guest', email: '', phone: '', preferredStyle: 'Minimal', addresses: [{ id: 'home', label: 'Home', text: '' }] };
      state.cart = [];
      state.wishlist = [];
      state.wardrobe = [];
      state.savedOutfits = [];
      state.orders = [];
      state.serviceBookings = [];
      localStorage.removeItem('stylesense_app_state');
      const label = document.getElementById('account-btn-label');
      if (label) label.textContent = 'Sign In';
      window.renderWardrobe?.();
      window.updateCartUI?.();
    }
  });
  loadFirestoreProducts();
}
