import { Product, Order, ServiceProvider, ServiceBooking, AnalyticsData } from './types';

const BASE_URL = '/api';

export async function fetchProducts(params?: {
  category?: string;
  slot?: string;
  search?: string;
  under2000?: boolean;
  sort?: string;
}): Promise<Product[]> {
  const query = new URLSearchParams();
  if (params?.category) query.append('category', params.category);
  if (params?.slot) query.append('slot', params.slot);
  if (params?.search) query.append('search', params.search);
  if (params?.under2000) query.append('under2000', 'true');
  if (params?.sort) query.append('sort', params.sort);

  const res = await fetch(`${BASE_URL}/products?${query.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch products');
  const json = await res.json();
  return json.data;
}

export async function addProduct(product: Partial<Product>): Promise<Product> {
  const res = await fetch(`${BASE_URL}/products`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(product),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || 'Failed to add product');
  return json.data;
}

export async function updateProduct(id: string, updates: Partial<Product>): Promise<Product> {
  const res = await fetch(`${BASE_URL}/products/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || 'Failed to update product');
  return json.data;
}

export async function deleteProduct(id: string): Promise<void> {
  const res = await fetch(`${BASE_URL}/products/${id}`, {
    method: 'DELETE',
  });
  if (!res.ok) {
    const json = await res.json();
    throw new Error(json.message || 'Failed to delete product');
  }
}

export async function fetchOrders(): Promise<Order[]> {
  const res = await fetch(`${BASE_URL}/orders`);
  if (!res.ok) throw new Error('Failed to fetch orders');
  const json = await res.json();
  return json.data;
}

export async function createOrder(orderData: {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  deliveryAddress: string;
  items: { id: string; name: string; price: number; quantity: number; slot?: string; image?: string }[];
  paymentMode: string;
}): Promise<Order> {
  const res = await fetch(`${BASE_URL}/orders`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(orderData),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || 'Failed to create order');
  return json.data;
}

export async function updateOrderStatus(orderId: string, status: Order['status']): Promise<Order> {
  const res = await fetch(`${BASE_URL}/orders/${orderId}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status }),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || 'Failed to update status');
  return json.data;
}

export async function fetchAnalytics(): Promise<AnalyticsData> {
  const res = await fetch(`${BASE_URL}/analytics`);
  if (!res.ok) throw new Error('Failed to fetch analytics');
  const json = await res.json();
  return json.data;
}

export async function fetchServices(city?: string, category?: string): Promise<ServiceProvider[]> {
  const query = new URLSearchParams();
  if (city) query.append('city', city);
  if (category && category !== 'All') query.append('category', category);

  const res = await fetch(`${BASE_URL}/services?${query.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch services');
  const json = await res.json();
  return json.data;
}

export async function loginServiceProvider(email: string, password: string): Promise<ServiceProvider> {
  const res = await fetch(`${BASE_URL}/services/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || 'Login failed');
  return json.data;
}

export async function fetchBookings(providerId?: string, customerEmail?: string): Promise<ServiceBooking[]> {
  const query = new URLSearchParams();
  if (providerId) query.append('providerId', providerId);
  if (customerEmail) query.append('customerEmail', customerEmail);

  const res = await fetch(`${BASE_URL}/bookings?${query.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch bookings');
  const json = await res.json();
  return json.data;
}

export async function createBooking(data: {
  providerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  serviceNotes: string;
  preferredDate: string;
  serviceType: string;
}): Promise<ServiceBooking> {
  const res = await fetch(`${BASE_URL}/bookings`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || 'Failed to create booking');
  return json.data;
}

export async function updateBookingStatus(
  bookingId: string,
  status: ServiceBooking['status'],
  providerNotes?: string
): Promise<ServiceBooking> {
  const res = await fetch(`${BASE_URL}/bookings/${bookingId}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status, providerNotes }),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || 'Failed to update booking status');
  return json.data;
}

export async function sendChatMessage(message: string): Promise<string> {
  const res = await fetch(`${BASE_URL}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message }),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || 'Failed to chat');
  return json.reply;
}
