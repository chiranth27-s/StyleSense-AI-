export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  oldPrice?: number;
  rating: number;
  category: string;
  gender: 'Women' | 'Men' | 'Unisex';
  slot: 'Topwear' | 'Bottomwear' | 'Footwear' | 'Accessories';
  color: string;
  palette: string;
  styles: string[];
  occasions: string[];
  image: string;
  featured: boolean;
  tag?: string | null;
  stock: number;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image?: string;
  slot?: string;
}

export interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  deliveryAddress: string;
  items: OrderItem[];
  subtotal: number;
  shipping: number;
  total: number;
  status: 'Processing' | 'Dispatched' | 'Delivered' | 'Cancelled';
  paymentMode: string;
  createdAt: string;
}

export interface ServiceProvider {
  id: string;
  name: string;
  category: 'Tailoring' | 'Shoe repair' | 'Bag repair' | 'Watch repair';
  city: string;
  area: string;
  pin: string;
  rating: number;
  priceRange: string;
  icon: string;
  desc: string;
  pickup: boolean;
  contactEmail: string;
  contactPhone: string;
  completedJobsCount: number;
  totalEarnings: number;
}

export interface ServiceBooking {
  id: string;
  providerId: string;
  providerName: string;
  category: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  serviceNotes: string;
  preferredDate: string;
  serviceType: 'Doorstep Pickup & Return' | 'Direct Studio Drop-off';
  status: 'Pickup Scheduled' | 'Received in Workshop' | 'In-Progress / Crafting' | 'Ready for Delivery' | 'Completed';
  cost: number;
  createdAt: string;
  providerNotes?: string;
}

export interface AnalyticsData {
  totalRevenue: number;
  todayRevenue: number;
  totalOrders: number;
  averageOrderValue: number;
  conversionRate: string;
  dispatchedCount: number;
  processingCount: number;
  deliveredCount: number;
  aestheticCounts: Record<string, number>;
  salesTrend: { hour: string; sales: number }[];
  recentOrders: Order[];
}

export interface WardrobeItem {
  id: string;
  name: string;
  slot: 'Topwear' | 'Bottomwear' | 'Footwear' | 'Accessories';
  color: string;
  image: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  name: string;
  phone: string;
  role: 'customer' | 'admin' | 'service_provider';
  preferredStyle?: string;
  providerId?: string; // If service_provider
  addresses?: { id: string; label: string; text: string }[];
}

export type ActiveView = 'home' | 'stylist' | 'admin' | 'service-portal';
